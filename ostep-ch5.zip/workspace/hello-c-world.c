#include <stdio.h>

main() {
    printf("Hello World!\n");
}
